// let nama = 'uun patrio';
// let usia = 23;
// let tinggiBadan = 160.5;
// let beratBadan;
// let pacar = 2;

// beratBadan = 57;

// switch(pacar){
//     case 1:
//         pacar = 'punya 1 aja'
//         break
//     case 2:
//         pacar = 'punya pacar 2, aku cukup playboy'
//         break
//     default:
//         pacar = 'belum punya pacar'
//         break
// }

// let saldoAwal = 50000
// let saldoTambahan = 80000
// const hutang = 30000
// const saldoAkhir = saldoAwal + saldoTambahan - hutang

// const x = 9
// const y = 2
// const z = x/y

// alert(`nilai x=${x} / nilai y=${y} maka hasilnya adalah ${z}`)

// // alert(
// //     `nama saya ${nama} usia saya itu ${usia} tahun, tinggi badan saya adalah ${tinggiBadan}, berat badan saya 
// //     ${beratBadan}kg dan pacar saya ${pacar}`)

// // alert(
// //     `saldo awal saya sebesar Rp.${saldoAwal} & saldo tambahan yang akan saya miliki sebesar Rp.${saldoTambahan}
// //     jadi total saldo yang saya miliki sebanyak Rp.${saldoAkhir}`,
// // )

// let namaMhs = ['dio','holden','rian']
// namaMhs.push('ikhsan','rafli')
// namaMhs.shift()
// namaMhs.pop()
// alert(namaMhs)

// let namaMhs = []
// namaMhs[0] = 'asro'
// namaMhs[1] = 'asma'
// namaMhs[2] = 'serly'
// namaMhs.push('bredny','elfa','mikael')
// namaMhs.pop()

// alert(namaMhs)


// `alert(namaMhs)`

// alert(namaMhs[1])

// for(let i=1; i<=10; i=i+1){
//     console.log('uun patrio')
// }

const namaMhs = ['iqbal', 'akbar', 'ronanda']

for(let i = 0; i<=namaMhs.length; i++){
    console.log(namaMhs[i])
}